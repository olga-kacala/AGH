package orkiestra;

public class Flute implements Instrument{
   public void play () {
        System.out.println("flutututu");
    }
}
