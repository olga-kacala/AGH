package orkiestra;

public interface Instrument {
    void play();
}
