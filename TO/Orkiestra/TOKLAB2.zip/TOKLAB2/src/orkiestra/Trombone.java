package orkiestra;

public class Trombone implements Instrument {
    public void play () {
        System.out.println("strutututu");
    }
}
