package agh.ics.oop.model;

public enum MoveDirection {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT
}
