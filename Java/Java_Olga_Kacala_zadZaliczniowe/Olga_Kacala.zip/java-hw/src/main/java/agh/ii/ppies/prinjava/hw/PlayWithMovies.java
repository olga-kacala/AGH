package agh.ii.ppies.prinjava.hw;

import agh.ii.ppies.prinjava.hw.dal.ImdbTop250;
import agh.ii.ppies.prinjava.hw.model.Movie;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

interface PlayWithMovies {

    /**
     * Returns the movies (only titles) directed (or co-directed) by a given director
     */
    static Set<String> ex01(String director) {
        return
                ImdbTop250.movies()
                .orElseThrow(() -> new RuntimeException("Failed to load movies"))
                .stream()
                .filter(movie->movie.directors().contains(director))
                .map(Movie::title)
                .collect(Collectors.toSet());

    }

    /**
     * Returns the movies (only titles) in which an actor played
     */
    static Set<String> ex02(String actor) {

        return
        ImdbTop250.movies()
                .orElseThrow(()-> new RuntimeException("Failed to load movies"))
                .stream().filter(movie ->movie.actors().contains(actor))
                .map(Movie::title)
                .collect(Collectors.toSet());
    }

    /**
     * Returns the number of movies per director (as a map)
     */
    static Map<String, Long> ex03() {

        return
                ImdbTop250.movies()
                        .orElseThrow(()->new RuntimeException("Failed to load movies"))
                        .stream()
                        .flatMap(movie->movie.directors().stream())
                        .collect(Collectors.groupingBy(director->director, Collectors.counting()));

    }

    /**
     * Returns the 10 directors with the most films on the list
     */
    static Map<String, Long> ex04() {

        return
                ImdbTop250.movies()
                .orElseThrow(() -> new RuntimeException("Failed to load movies"))
                .stream()
                .flatMap(movie -> movie.directors().stream())
                .collect(Collectors.groupingBy(director -> director, Collectors.counting()))
                .entrySet().stream()
                .sorted((entry1, entry2) -> Long.compare(entry2.getValue(), entry1.getValue()))
                .limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }
}

